export class EjercicioInsertDTO {
  idTema: number = 0
  enunciado: string = ''
  contenidoJson: string = ''
  respuestaCorrecta: string = ''
  nivelDificultad: number = 0
  generadoPorIa: boolean = false
  estado: string = ''
}
