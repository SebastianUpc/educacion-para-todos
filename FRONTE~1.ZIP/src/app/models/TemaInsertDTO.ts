export class TemaInsertDTO {
  materia: string = ''
  nombre: string = ''
}
