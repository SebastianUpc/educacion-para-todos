export class TemaDTO {
  id: number = 0
  materia: string = ''
  nombre: string = ''
}
