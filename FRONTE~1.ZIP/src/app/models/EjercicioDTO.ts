export class EjercicioDTO {
  id: number = 0
  idTema: number = 0
  nombreTema: string = ''
  enunciado: string = ''
  contenidoJson: string = ''
  nivelDificultad: number = 0
  generadoPorIa: boolean = false
  estado: string = ''
}
